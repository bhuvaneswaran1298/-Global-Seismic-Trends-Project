# Global Seismic Trends — Backend Source Code

This package contains the backend/data layer extracted from the supplied Global Seismic Trends project.

## Included modules

- `src/seismic/usgs_client.py` — retrieves earthquake event data from the USGS FDSN service.
- `src/seismic/cleaner.py` — validates, normalizes and enriches earthquake records.
- `src/seismic/analytics.py` — reusable analytical calculations.
- `src/seismic/storage.py` — CSV and MySQL persistence utilities.
- `sql/` — database schema and analytical SQL queries.
- `scripts/` — data ingestion and analysis command-line scripts.
- `tests/` — backend unit tests.

## Important architecture note

The original application is a Streamlit application, not a separately deployed frontend + REST API system. This backend package contains the reusable Python data-processing, analytics, USGS integration and database modules. The original Streamlit dashboard (`app.py`) is intentionally excluded. The modules are consumed by that dashboard in the complete project.

This package does **not** include an independent FastAPI/REST server. Do not describe it as a standalone API backend unless the project is refactored to add API endpoints.

## Setup

Python 3.10 or newer is required.

```bash
python -m venv .venv
```

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

macOS/Linux:
```bash
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` only if using MySQL. Never share a real `.env` file containing credentials.

## Run backend scripts

```bash
python scripts/fetch_and_store.py
python scripts/run_analysis.py
```

Run tests:

```bash
pytest
```

## Database

Create the database and tables using `sql/schema.sql`. Configure the database connection using the variable names documented in `.env.example`.

## Delivery note

For the complete runnable application, use the separate Full Project Source package, because the Streamlit UI is not included in this backend-only archive.
