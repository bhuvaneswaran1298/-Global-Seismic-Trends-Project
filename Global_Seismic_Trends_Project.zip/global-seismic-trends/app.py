"""Streamlit dashboard for Global Seismic Trends."""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from seismic.cleaner import clean_features  # noqa: E402
from seismic.storage import (  # noqa: E402
    create_db_engine,
    get_database_url,
    load_csv,
    load_mysql,
    save_csv,
    upsert_mysql,
)
from seismic.usgs_client import USGSEarthquakeClient, default_five_year_window  # noqa: E402

st.set_page_config(
    page_title="Global Seismic Trends",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      .block-container {padding-top: 1.6rem; padding-bottom: 2.2rem; max-width: 1500px;}
      [data-testid="stMetric"] {background: #f7f9fc; border: 1px solid #e7ebf2; padding: 14px 16px; border-radius: 12px;}
      [data-testid="stMetricLabel"] p {font-size: .83rem; color: #526071;}
      .section-note {color: #637083; font-size: .9rem;}
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_data(ttl=300, show_spinner=False)
def read_database() -> pd.DataFrame:
    return load_mysql(create_db_engine())


def get_data() -> tuple[pd.DataFrame, str]:
    if get_database_url():
        try:
            frame = read_database()
            if not frame.empty:
                return frame, "MySQL database"
        except Exception as exc:  # database availability should not block CSV mode
            st.sidebar.warning(f"MySQL unavailable: {exc}")
    csv_path = ROOT / "data" / "processed" / "earthquakes.csv"
    if csv_path.exists():
        return load_csv(csv_path), "processed CSV"
    return pd.DataFrame(), "no dataset loaded"


def fetch_dataset(start: date, end: date, min_magnitude: float | None, load_to_mysql: bool) -> int:
    client = USGSEarthquakeClient()
    raw_features = client.fetch(start, end, min_magnitude)
    frame = clean_features(raw_features)
    save_csv(frame, ROOT / "data" / "processed" / "earthquakes.csv")
    if load_to_mysql:
        engine = create_db_engine()
        upsert_mysql(frame, engine)
    read_database.clear()
    return len(frame)


st.title("🌍 Global Seismic Trends")
st.subheader("Data-Driven Earthquake Insights")
st.caption("USGS earthquake catalogue · Python analytics · MySQL · Streamlit")

with st.sidebar:
    st.header("Data source")
    st.caption("Fetch the latest five-year catalogue from the official USGS FDSN event service.")
    default_start, default_end = default_five_year_window()
    fetch_all = st.checkbox("Include all reported magnitudes", value=False,
                            help="When off, the API request uses the magnitude threshold below.")
    magnitude_threshold = st.slider("Minimum magnitude", 0.0, 8.0, 2.5, 0.5, disabled=fetch_all)
    save_mysql = st.checkbox("Also load into MySQL", value=bool(get_database_url()), disabled=not bool(get_database_url()))
    if st.button("Fetch five years from USGS", type="primary", use_container_width=True):
        with st.spinner("Requesting monthly USGS data, cleaning records and saving the dataset…"):
            try:
                count = fetch_dataset(
                    default_start,
                    default_end,
                    None if fetch_all else magnitude_threshold,
                    save_mysql,
                )
                st.success(f"Saved {count:,} unique earthquake records.")
                st.rerun()
            except Exception as exc:
                st.error(f"Data retrieval failed: {exc}")
    st.divider()
    st.header("Dashboard filters")

frame, source_label = get_data()
if frame.empty:
    st.info(
        "No dataset is available yet. Use **Fetch five years from USGS** in the sidebar, "
        "or run `python scripts/fetch_and_store.py` from the project folder."
    )
    st.markdown(
        "The dashboard does not use fabricated demonstration records. It will display "
        "charts after a real USGS dataset has been downloaded."
    )
    st.stop()

frame["time"] = pd.to_datetime(frame["time"], utc=True, errors="coerce")
frame = frame.dropna(subset=["time"]).copy()
if frame.empty:
    st.warning("The loaded dataset does not contain valid event timestamps.")
    st.stop()

min_date = frame["time"].min().date()
max_date = frame["time"].max().date()
with st.sidebar:
    selected_dates = st.date_input(
        "Event date range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date,
    )
    magnitude_min = float(frame["mag"].min()) if frame["mag"].notna().any() else 0.0
    magnitude_max = float(frame["mag"].max()) if frame["mag"].notna().any() else 10.0
    if magnitude_max <= magnitude_min:
        magnitude_max = magnitude_min + 0.1
    selected_mag = st.slider(
        "Minimum event magnitude",
        min_value=float(max(-2, magnitude_min)),
        max_value=float(min(10, magnitude_max)),
        value=float(max(-2, magnitude_min)),
        step=0.1,
    )
    status_values = sorted(frame["status"].fillna("not_reported").astype(str).unique().tolist()) if "status" in frame else []
    selected_status = st.multiselect("Review status", status_values, default=status_values)
    alert_values = sorted(frame["alert"].fillna("not_reported").astype(str).unique().tolist()) if "alert" in frame else []
    selected_alert = st.multiselect("PAGER alert level", alert_values, default=alert_values)

if isinstance(selected_dates, tuple) and len(selected_dates) == 2:
    date_start, date_end = selected_dates
else:
    date_start = date_end = selected_dates

filtered = frame[
    (frame["time"].dt.date >= date_start)
    & (frame["time"].dt.date <= date_end)
].copy()
if "mag" in filtered:
    filtered = filtered[filtered["mag"].notna() & (filtered["mag"] >= selected_mag)]
if selected_status and "status" in filtered:
    normalized_status = filtered["status"].fillna("not_reported").astype(str)
    filtered = filtered[normalized_status.isin(selected_status)]
if selected_alert and "alert" in filtered:
    normalized_alert = filtered["alert"].fillna("not_reported").astype(str)
    filtered = filtered[normalized_alert.isin(selected_alert)]

st.caption(f"Data source: **{source_label}** · Showing **{len(filtered):,}** of {len(frame):,} records")

valid_mag = filtered["mag"].dropna() if "mag" in filtered else pd.Series(dtype=float)
valid_depth = filtered["depth_km"].dropna() if "depth_km" in filtered else pd.Series(dtype=float)
ts_count = int(filtered["tsunami"].fillna(0).eq(1).sum()) if "tsunami" in filtered else 0
strong_count = int(valid_mag.ge(6).sum())

kpi_cols = st.columns(4)
kpi_cols[0].metric("Earthquake events", f"{len(filtered):,}")
kpi_cols[1].metric("Average magnitude", f"{valid_mag.mean():.2f}" if not valid_mag.empty else "—")
kpi_cols[2].metric("Magnitude ≥ 6.0", f"{strong_count:,}")
kpi_cols[3].metric("Tsunami-flagged events", f"{ts_count:,}")

st.divider()

left, right = st.columns([1.55, 1])
with left:
    st.subheader("Global epicentre distribution")
    map_data = filtered.dropna(subset=["latitude", "longitude"]).copy()
    if not map_data.empty:
        if len(map_data) > 5000:
            map_data = map_data.sample(5000, random_state=42)
        fig = px.scatter_geo(
            map_data,
            lat="latitude",
            lon="longitude",
            color="mag" if "mag" in map_data and map_data["mag"].notna().any() else None,
            hover_name="place" if "place" in map_data else None,
            hover_data=[column for column in ["time", "depth_km", "status", "alert"] if column in map_data],
            projection="natural earth",
            color_continuous_scale="Turbo",
            height=490,
            opacity=0.72,
        )
        fig.update_layout(margin=dict(l=0, r=0, t=5, b=0), coloraxis_colorbar_title="Magnitude")
        st.plotly_chart(fig, use_container_width=True)
        if len(filtered) > len(map_data):
            st.caption("Map displays a reproducible 5,000-event sample for browser performance; KPIs and other charts use all filtered rows.")
    else:
        st.info("No records with valid latitude/longitude in this filter.")

with right:
    st.subheader("Magnitude distribution")
    if not valid_mag.empty:
        fig = px.histogram(filtered.dropna(subset=["mag"]), x="mag", nbins=35,
                           labels={"mag": "Magnitude", "count": "Events"}, height=230)
        fig.update_layout(margin=dict(l=0, r=0, t=10, b=0), showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No magnitude values available.")

    st.subheader("Depth categories")
    if "depth_category" in filtered and filtered["depth_category"].notna().any():
        depth_counts = filtered["depth_category"].value_counts().rename_axis("category").reset_index(name="events")
        fig = px.pie(depth_counts, names="category", values="events", hole=0.55, height=235)
        fig.update_layout(margin=dict(l=0, r=0, t=0, b=0), legend_title_text="")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No depth values available.")

col1, col2 = st.columns(2)
with col1:
    st.subheader("Earthquake activity over time")
    monthly = (
        filtered.set_index("time").resample("MS").size().rename("events").reset_index()
        if not filtered.empty else pd.DataFrame(columns=["time", "events"])
    )
    fig = px.line(monthly, x="time", y="events", markers=True,
                  labels={"time": "Month (UTC)", "events": "Earthquake events"}, height=330)
    fig.update_layout(margin=dict(l=0, r=0, t=10, b=0))
    st.plotly_chart(fig, use_container_width=True)

with col2:
    st.subheader("Events by UTC hour")
    if "hour" in filtered and filtered["hour"].notna().any():
        hourly = filtered.groupby("hour", dropna=True).size().reindex(range(24), fill_value=0).rename("events").reset_index()
        fig = px.bar(hourly, x="hour", y="events", labels={"hour": "Hour (UTC)", "events": "Events"}, height=330)
        fig.update_layout(margin=dict(l=0, r=0, t=10, b=0), xaxis=dict(dtick=1))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No hourly values available.")

col3, col4 = st.columns(2)
with col3:
    st.subheader("Magnitude by depth")
    scatter = filtered.dropna(subset=["mag", "depth_km"])
    if not scatter.empty:
        if len(scatter) > 8000:
            scatter = scatter.sample(8000, random_state=42)
        fig = px.scatter(scatter, x="depth_km", y="mag", color="mag",
                         hover_name="place" if "place" in scatter else None,
                         labels={"depth_km": "Depth (km)", "mag": "Magnitude"}, height=330)
        fig.update_layout(margin=dict(l=0, r=0, t=10, b=0))
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No magnitude/depth pairs available.")

with col4:
    st.subheader("Reporting status")
    if "status" in filtered and filtered["status"].notna().any():
        status_counts = filtered["status"].fillna("not reported").value_counts().rename_axis("status").reset_index(name="events")
        fig = px.bar(status_counts, x="status", y="events", color="status", height=330)
        fig.update_layout(margin=dict(l=0, r=0, t=10, b=0), showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Review status is not available in these records.")

st.divider()
st.subheader("Largest events in the selected period")
top_columns = [column for column in ["time", "mag", "place", "depth_km", "magType", "status", "alert", "tsunami"] if column in filtered.columns]
top_events = filtered.dropna(subset=["mag"]).sort_values("mag", ascending=False).head(20)[top_columns]
st.dataframe(top_events, use_container_width=True, hide_index=True)

csv_bytes = filtered.to_csv(index=False).encode("utf-8")
st.download_button(
    "Download filtered earthquake data (CSV)",
    data=csv_bytes,
    file_name="global_seismic_trends_filtered.csv",
    mime="text/csv",
)

with st.expander("Data coverage and interpretation notes"):
    st.markdown(
        """
        - The 26 catalogue fields originate from the USGS event GeoJSON response. `alert` is retained as an optional extra because later project tasks refer to PAGER alert levels.
        - Missing numeric measurements remain null; they are not replaced with zero, which would bias averages and error metrics.
        - Country and continent are populated only when a recognized country name appears in the USGS `place` string. Many USGS locations do not name a country, so geographic groupings can be incomplete.
        - The catalogue does not provide direct casualty counts or monetary loss totals. Those analyses require a separately sourced impact dataset linked by event ID or another documented key.
        - The dashboard describes observed catalogue records. It is not an earthquake prediction tool or an official hazard forecast.
        """
    )
