"""Reusable Pandas exploratory-analysis functions."""

from __future__ import annotations

from typing import Any

import pandas as pd


def dataset_summary(df: pd.DataFrame) -> dict[str, Any]:
    if df.empty:
        return {"total_events": 0, "message": "No earthquake records are available."}

    times = pd.to_datetime(df.get("time", pd.Series(index=df.index, dtype="object")), utc=True, errors="coerce")
    magnitudes = pd.to_numeric(df.get("mag", pd.Series(index=df.index, dtype="float64")), errors="coerce")
    depths = pd.to_numeric(df.get("depth_km", pd.Series(index=df.index, dtype="float64")), errors="coerce")
    tsunami = pd.to_numeric(df.get("tsunami", pd.Series(index=df.index, dtype="float64")), errors="coerce")

    summary: dict[str, Any] = {
        "total_events": int(len(df)),
        "first_event_utc": times.min().isoformat() if times.notna().any() else None,
        "last_event_utc": times.max().isoformat() if times.notna().any() else None,
        "mean_magnitude": round(float(magnitudes.mean()), 3) if magnitudes.notna().any() else None,
        "median_magnitude": round(float(magnitudes.median()), 3) if magnitudes.notna().any() else None,
        "mean_depth_km": round(float(depths.mean()), 3) if depths.notna().any() else None,
        "tsunami_flagged_events": int(tsunami.eq(1).sum()),
        "records_with_country": int(df["country"].notna().sum()) if "country" in df else 0,
        "records_with_continent": int(df["continent"].notna().sum()) if "continent" in df else 0,
        "review_status_counts": (
            df["status"].fillna("not_reported").value_counts().to_dict()
            if "status" in df else {}
        ),
        "magnitude_type_counts": (
            df["magType"].fillna("not_reported").value_counts().to_dict()
            if "magType" in df else {}
        ),
    }
    return summary


def yearly_counts(df: pd.DataFrame) -> pd.DataFrame:
    work = df.copy()
    work["time"] = pd.to_datetime(work["time"], utc=True, errors="coerce")
    work = work.dropna(subset=["time"])
    if work.empty:
        return pd.DataFrame(columns=["year", "event_count", "yoy_growth_percent"])
    result = work.groupby(work["time"].dt.year).size().rename("event_count").reset_index()
    result = result.rename(columns={"time": "year"})
    result["yoy_growth_percent"] = result["event_count"].pct_change().mul(100).round(2)
    return result


def strongest_events(df: pd.DataFrame, limit: int = 10) -> pd.DataFrame:
    if "mag" not in df:
        return pd.DataFrame()
    columns = [col for col in ["id", "time", "place", "mag", "magType", "depth_km"] if col in df]
    return df.dropna(subset=["mag"]).sort_values("mag", ascending=False).head(limit)[columns]
