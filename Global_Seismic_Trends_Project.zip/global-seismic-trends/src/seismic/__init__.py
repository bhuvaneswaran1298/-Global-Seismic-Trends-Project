"""Global Seismic Trends: Data-Driven Earthquake Insights."""

__version__ = "1.0.0"
