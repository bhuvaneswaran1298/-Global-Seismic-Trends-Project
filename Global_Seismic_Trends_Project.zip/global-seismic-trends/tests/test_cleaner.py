from datetime import datetime, timezone

import pandas as pd

from seismic.cleaner import USGS_FEATURE_COLUMNS, clean_features, extract_country


def _feature(event_id: str, time_ms: int, depth: float = 12.5, place: str = "8 km S of Denver, Colorado, USA"):
    return {
        "type": "Feature",
        "id": event_id,
        "properties": {
            "time": time_ms,
            "updated": time_ms + 1000,
            "mag": 5.4,
            "magType": "mww",
            "place": place,
            "status": "reviewed",
            "tsunami": 0,
            "sig": 450,
            "net": "us",
            "nst": 35,
            "dmin": 0.5,
            "rms": 0.7,
            "gap": 90,
            "magError": 0.1,
            "depthError": 1.2,
            "magNst": 30,
            "locationSource": "us",
            "magSource": "us",
            "types": ",origin,phase-data,",
            "ids": f",{event_id},",
            "sources": ",us,",
            "type": "earthquake",
            "alert": "ORANGE",
        },
        "geometry": {"type": "Point", "coordinates": [-104.99, 39.74, depth]},
    }


def test_clean_features_preserves_26_fields_and_adds_derived_columns():
    timestamp = int(datetime(2025, 1, 2, 3, 4, tzinfo=timezone.utc).timestamp() * 1000)
    df = clean_features([_feature("evt-1", timestamp)])

    assert len(USGS_FEATURE_COLUMNS) == 26
    assert df.loc[0, "id"] == "evt-1"
    assert df.loc[0, "latitude"] == 39.74
    assert df.loc[0, "longitude"] == -104.99
    assert df.loc[0, "depth_km"] == 12.5
    assert df.loc[0, "year"] == 2025
    assert df.loc[0, "month"] == 1
    assert df.loc[0, "day_of_week"] == "Thursday"
    assert bool(df.loc[0, "is_shallow_50km"]) is True
    assert df.loc[0, "depth_category"] == "shallow"
    assert df.loc[0, "country"] == "United States"
    assert df.loc[0, "alert"] == "orange"


def test_duplicate_event_ids_are_removed():
    timestamp = int(datetime(2025, 1, 2, tzinfo=timezone.utc).timestamp() * 1000)
    df = clean_features([_feature("evt-1", timestamp), _feature("evt-1", timestamp)])
    assert len(df) == 1


def test_missing_numeric_values_remain_missing_not_zero():
    timestamp = int(datetime(2025, 1, 2, tzinfo=timezone.utc).timestamp() * 1000)
    item = _feature("evt-2", timestamp)
    item["properties"]["mag"] = None
    item["properties"]["nst"] = None
    df = clean_features([item])
    assert pd.isna(df.loc[0, "mag"])
    assert pd.isna(df.loc[0, "nst"])


def test_country_extraction_does_not_guess_from_generic_place_text():
    assert extract_country("12 km N of a remote village") is None
    assert extract_country("offshore of USA") == "United States"
    assert extract_country("5 km E of South Georgia Island") is None


def test_empty_input_returns_valid_empty_schema():
    df = clean_features([])
    assert df.empty
    assert "id" in df.columns
    assert "year" in df.columns
