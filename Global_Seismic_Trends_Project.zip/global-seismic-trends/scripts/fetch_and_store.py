#!/usr/bin/env python3
"""Fetch the USGS catalogue, clean it, export CSV, and optionally load MySQL."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import date
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from seismic.cleaner import clean_features  # noqa: E402
from seismic.storage import create_db_engine, save_csv, upsert_mysql  # noqa: E402
from seismic.usgs_client import USGSEarthquakeClient, default_five_year_window  # noqa: E402


def parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Date must use YYYY-MM-DD format") from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Download the USGS earthquake catalogue and prepare it for analysis."
    )
    parser.add_argument("--start", type=parse_date, help="Start date (YYYY-MM-DD); defaults to five years ago")
    parser.add_argument("--end", type=parse_date, help="End date (YYYY-MM-DD); defaults to today (UTC)")
    parser.add_argument("--min-magnitude", type=float, default=None,
                        help="Optional USGS magnitude filter. Omit to include all reported magnitudes.")
    parser.add_argument("--csv", default="data/processed/earthquakes.csv", help="Clean CSV output path")
    parser.add_argument("--save-raw", action="store_true", help="Also save the source GeoJSON response locally")
    parser.add_argument("--load-mysql", action="store_true", help="Upsert cleaned records into MySQL using DATABASE_URL")
    parser.add_argument("--log-level", default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return parser


def main() -> int:
    args = build_parser().parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    default_start, default_end = default_five_year_window()
    start_date = args.start or default_start
    end_date = args.end or default_end
    if end_date < start_date:
        raise SystemExit("The end date must be on or after the start date.")

    client = USGSEarthquakeClient()
    features = client.fetch(start_date, end_date, args.min_magnitude)
    logging.info("Downloaded %s unique USGS events", len(features))

    cleaned = clean_features(features)
    output_path = save_csv(cleaned, PROJECT_ROOT / args.csv)
    print(f"Cleaned records: {len(cleaned):,}")
    print(f"CSV saved: {output_path}")

    if args.save_raw:
        raw_dir = PROJECT_ROOT / "data" / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        raw_path = raw_dir / f"usgs_events_{start_date:%Y%m%d}_{end_date:%Y%m%d}.geojson"
        with raw_path.open("w", encoding="utf-8") as handle:
            json.dump({"type": "FeatureCollection", "features": features}, handle, ensure_ascii=False)
        print(f"Raw GeoJSON saved: {raw_path}")

    if args.load_mysql:
        engine = create_db_engine()
        inserted = upsert_mysql(cleaned, engine)
        print(f"Records upserted into MySQL: {inserted:,}")

    if not cleaned.empty:
        print(f"Time range: {cleaned['time'].min()} to {cleaned['time'].max()}")
        print(f"Records with explicit country: {cleaned['country'].notna().sum():,}")
        print(f"Records with continent: {cleaned['continent'].notna().sum():,}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
