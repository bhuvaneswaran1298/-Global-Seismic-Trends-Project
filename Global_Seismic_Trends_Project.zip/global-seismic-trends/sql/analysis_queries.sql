-- Global Seismic Trends: SQL analyst tasks
-- Target: MySQL 8.0+. Run after loading data with scripts/fetch_and_store.py.
-- Parameters are shown as comments; replace literals/thresholds as required.

-- 1. Top 10 strongest earthquakes
SELECT id, `time`, place, mag, magType, depth_km
FROM earthquakes WHERE mag IS NOT NULL
ORDER BY mag DESC, `time` DESC LIMIT 10;

-- 2. Top 10 deepest earthquakes
SELECT id, `time`, place, depth_km, mag
FROM earthquakes WHERE depth_km IS NOT NULL
ORDER BY depth_km DESC LIMIT 10;

-- 3. Shallow earthquakes under 50 km with magnitude greater than 7.5
SELECT id, `time`, place, depth_km, mag
FROM earthquakes
WHERE depth_km < 50 AND mag > 7.5
ORDER BY mag DESC;

-- 4. Average depth per continent. Countries/continents are populated only when
--    the USGS place text explicitly includes a recognized country.
SELECT continent, COUNT(*) AS event_count, ROUND(AVG(depth_km), 2) AS avg_depth_km
FROM earthquakes
WHERE continent IS NOT NULL AND depth_km IS NOT NULL
GROUP BY continent ORDER BY avg_depth_km DESC;

-- 5. Average magnitude per magnitude type
SELECT magType, COUNT(*) AS event_count, ROUND(AVG(mag), 2) AS avg_magnitude
FROM earthquakes WHERE magType IS NOT NULL AND mag IS NOT NULL
GROUP BY magType ORDER BY event_count DESC;

-- 6. Year with the most earthquakes
SELECT year, COUNT(*) AS earthquake_count
FROM earthquakes WHERE year IS NOT NULL
GROUP BY year ORDER BY earthquake_count DESC LIMIT 1;

-- 7. Month with the highest number of earthquakes (all years combined)
SELECT month, COUNT(*) AS earthquake_count
FROM earthquakes WHERE month IS NOT NULL
GROUP BY month ORDER BY earthquake_count DESC LIMIT 1;

-- 8. Day of week with the most earthquakes
SELECT day_of_week, COUNT(*) AS earthquake_count
FROM earthquakes WHERE day_of_week IS NOT NULL
GROUP BY day_of_week ORDER BY earthquake_count DESC LIMIT 1;

-- 9. Earthquake count by hour (UTC)
SELECT hour, COUNT(*) AS earthquake_count
FROM earthquakes WHERE hour IS NOT NULL
GROUP BY hour ORDER BY hour;

-- 10. Most active reporting network
SELECT net, COUNT(*) AS earthquake_count
FROM earthquakes WHERE net IS NOT NULL
GROUP BY net ORDER BY earthquake_count DESC LIMIT 10;

-- 11. Top five places with highest casualties
-- NOT COMPUTABLE from the specified USGS 26 fields. The event catalogue does not
-- contain a casualty-count field. Join a separately sourced, documented impact
-- dataset by event ID before attempting this analysis.

-- 12. Total estimated economic loss per continent
-- NOT COMPUTABLE from the specified USGS 26 fields. No monetary-loss field is
-- present. A separately sourced loss/impact dataset is required.

-- 13. Average economic loss by alert level
-- NOT COMPUTABLE from the USGS event fields. `alert` is an optional PAGER alert
-- category, not an economic-loss amount. Do not treat the alert colour as money.

-- 14. Reviewed vs automatic earthquakes
SELECT status, COUNT(*) AS earthquake_count
FROM earthquakes WHERE status IS NOT NULL
GROUP BY status ORDER BY earthquake_count DESC;

-- 15. Count by earthquake event type
SELECT `type`, COUNT(*) AS earthquake_count
FROM earthquakes WHERE `type` IS NOT NULL
GROUP BY `type` ORDER BY earthquake_count DESC;

-- 16. Number of earthquakes by associated data type (MySQL 8 JSON_TABLE)
SELECT TRIM(data_types.data_type) AS data_type, COUNT(DISTINCT e.id) AS earthquake_count
FROM earthquakes AS e
JOIN JSON_TABLE(
    CONCAT('["', REPLACE(TRIM(BOTH ',' FROM COALESCE(e.types, '')), ',', '","'), '"]'),
    '$[*]' COLUMNS(data_type VARCHAR(80) PATH '$')
) AS data_types
WHERE TRIM(data_types.data_type) <> ''
GROUP BY TRIM(data_types.data_type)
ORDER BY earthquake_count DESC;

-- 17. Average RMS and azimuthal gap per continent
SELECT continent, COUNT(*) AS event_count,
       ROUND(AVG(rms), 3) AS avg_rms,
       ROUND(AVG(gap), 2) AS avg_azimuthal_gap
FROM earthquakes
WHERE continent IS NOT NULL
GROUP BY continent ORDER BY event_count DESC;

-- 18. Events with high station coverage (example threshold: nst > 20)
SELECT id, `time`, place, mag, nst
FROM earthquakes WHERE nst > 20
ORDER BY nst DESC, `time` DESC;

-- 19. Number of tsunami-flagged events per year
SELECT year, SUM(CASE WHEN tsunami = 1 THEN 1 ELSE 0 END) AS tsunami_events
FROM earthquakes WHERE year IS NOT NULL
GROUP BY year ORDER BY year;

-- 20. Count earthquakes by PAGER alert level. Alert is optional and often NULL.
SELECT COALESCE(alert, 'not_reported') AS alert_level, COUNT(*) AS earthquake_count
FROM earthquakes GROUP BY COALESCE(alert, 'not_reported')
ORDER BY earthquake_count DESC;

-- 21. Five countries with highest average magnitude in the last five years
--     Country coverage is limited to records whose place text names a country.
SELECT country, COUNT(*) AS event_count, ROUND(AVG(mag), 2) AS avg_magnitude
FROM earthquakes
WHERE country IS NOT NULL AND mag IS NOT NULL
  AND `time` >= UTC_TIMESTAMP() - INTERVAL 5 YEAR
GROUP BY country HAVING COUNT(*) >= 5
ORDER BY avg_magnitude DESC, event_count DESC LIMIT 5;

-- 22. Countries with shallow (<70 km) and deep (>300 km) earthquakes in the same month
SELECT country, year, month,
       SUM(CASE WHEN depth_km < 70 THEN 1 ELSE 0 END) AS shallow_count,
       SUM(CASE WHEN depth_km > 300 THEN 1 ELSE 0 END) AS deep_count
FROM earthquakes
WHERE country IS NOT NULL AND year IS NOT NULL AND month IS NOT NULL
GROUP BY country, year, month
HAVING shallow_count > 0 AND deep_count > 0
ORDER BY year DESC, month DESC, country;

-- 23. Year-over-year growth in global earthquake count
WITH yearly AS (
    SELECT year, COUNT(*) AS event_count
    FROM earthquakes WHERE year IS NOT NULL GROUP BY year
), compared AS (
    SELECT year, event_count,
           LAG(event_count) OVER (ORDER BY year) AS previous_year_count
    FROM yearly
)
SELECT year, event_count, previous_year_count,
       CASE WHEN previous_year_count IS NULL OR previous_year_count = 0 THEN NULL
            ELSE ROUND((event_count - previous_year_count) * 100.0 / previous_year_count, 2)
       END AS yoy_growth_percent
FROM compared ORDER BY year;

-- 24. Three most active place/country labels by frequency + average magnitude.
--     A 70% frequency / 30% mean-magnitude normalized score is an explicit
--     project ranking heuristic, not an official seismic-risk score.
WITH regional AS (
    SELECT COALESCE(country, place) AS region_label,
           COUNT(*) AS event_count, AVG(mag) AS avg_magnitude
    FROM earthquakes
    WHERE COALESCE(country, place) IS NOT NULL AND mag IS NOT NULL
    GROUP BY COALESCE(country, place)
    HAVING COUNT(*) >= 10
), scored AS (
    SELECT region_label, event_count, avg_magnitude,
           0.70 * (event_count - MIN(event_count) OVER ()) /
                 NULLIF(MAX(event_count) OVER () - MIN(event_count) OVER (), 0)
         + 0.30 * (avg_magnitude - MIN(avg_magnitude) OVER ()) /
                 NULLIF(MAX(avg_magnitude) OVER () - MIN(avg_magnitude) OVER (), 0)
           AS activity_score
    FROM regional
)
SELECT region_label, event_count, ROUND(avg_magnitude, 2) AS avg_magnitude,
       ROUND(activity_score, 4) AS activity_score
FROM scored ORDER BY activity_score DESC LIMIT 3;

-- 25. Average depth by country within +/- 5 degrees latitude of the equator
SELECT country, COUNT(*) AS event_count, ROUND(AVG(depth_km), 2) AS avg_depth_km
FROM earthquakes
WHERE country IS NOT NULL AND latitude BETWEEN -5 AND 5 AND depth_km IS NOT NULL
GROUP BY country ORDER BY avg_depth_km DESC;

-- 26. Highest ratio of shallow (<70 km) to deep (>300 km) events by country
SELECT country,
       SUM(CASE WHEN depth_km < 70 THEN 1 ELSE 0 END) AS shallow_count,
       SUM(CASE WHEN depth_km > 300 THEN 1 ELSE 0 END) AS deep_count,
       ROUND(
           SUM(CASE WHEN depth_km < 70 THEN 1 ELSE 0 END) /
           NULLIF(SUM(CASE WHEN depth_km > 300 THEN 1 ELSE 0 END), 0), 3
       ) AS shallow_to_deep_ratio
FROM earthquakes
WHERE country IS NOT NULL AND depth_km IS NOT NULL
GROUP BY country
HAVING deep_count > 0
ORDER BY shallow_to_deep_ratio DESC;

-- 27. Mean magnitude difference between tsunami-flagged and non-tsunami events
SELECT
    ROUND(AVG(CASE WHEN tsunami = 1 THEN mag END), 3) AS avg_mag_tsunami_flagged,
    ROUND(AVG(CASE WHEN tsunami = 0 THEN mag END), 3) AS avg_mag_not_tsunami_flagged,
    ROUND(AVG(CASE WHEN tsunami = 1 THEN mag END) -
          AVG(CASE WHEN tsunami = 0 THEN mag END), 3) AS avg_magnitude_difference
FROM earthquakes WHERE mag IS NOT NULL AND tsunami IN (0, 1);

-- 28. Lowest catalogue data-quality ranking using RMS and azimuthal gap.
--     Both metrics are interpreted only among rows where both values exist.
SELECT id, `time`, place, mag, rms, gap,
       (rms / NULLIF(MAX(rms) OVER (), 0) + gap / NULLIF(MAX(gap) OVER (), 0)) / 2
          AS normalized_error_score
FROM earthquakes
WHERE rms IS NOT NULL AND gap IS NOT NULL
ORDER BY normalized_error_score DESC LIMIT 100;

-- 29. Consecutive events in the full time-ordered catalogue, within 50 km and 1 hour.
--     This deliberately means the next event globally, not the next event per region.
WITH ordered_events AS (
    SELECT id, `time`, latitude, longitude, place, mag,
           LEAD(id) OVER (ORDER BY `time`, id) AS next_id,
           LEAD(`time`) OVER (ORDER BY `time`, id) AS next_time,
           LEAD(latitude) OVER (ORDER BY `time`, id) AS next_latitude,
           LEAD(longitude) OVER (ORDER BY `time`, id) AS next_longitude
    FROM earthquakes
    WHERE `time` IS NOT NULL AND latitude IS NOT NULL AND longitude IS NOT NULL
), distances AS (
    SELECT *,
       6371 * 2 * ASIN(SQRT(
           POWER(SIN(RADIANS(next_latitude - latitude) / 2), 2) +
           COS(RADIANS(latitude)) * COS(RADIANS(next_latitude)) *
           POWER(SIN(RADIANS(next_longitude - longitude) / 2), 2)
       )) AS distance_km
    FROM ordered_events WHERE next_id IS NOT NULL
)
SELECT id AS first_event_id, next_id AS second_event_id,
       `time` AS first_event_time, next_time AS second_event_time,
       ROUND(distance_km, 2) AS distance_km, place, mag
FROM distances
WHERE next_time <= `time` + INTERVAL 1 HOUR AND distance_km <= 50
ORDER BY `time`;

-- 30. Regions with the highest frequency of deep-focus earthquakes (>300 km)
SELECT COALESCE(country, place) AS region_label,
       COUNT(*) AS deep_focus_count,
       ROUND(AVG(mag), 2) AS avg_magnitude
FROM earthquakes
WHERE depth_km > 300 AND COALESCE(country, place) IS NOT NULL
GROUP BY COALESCE(country, place)
ORDER BY deep_focus_count DESC LIMIT 10;
