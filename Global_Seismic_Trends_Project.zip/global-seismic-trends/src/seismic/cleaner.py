"""Normalize USGS GeoJSON features into a reproducible analytical data frame."""

from __future__ import annotations

import logging
import re
from functools import lru_cache
from typing import Any, Iterable

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)

# The 26 fields listed in the supplied project brief. Coordinates are read from
# GeoJSON geometry; the remaining fields are read from properties.
USGS_FEATURE_COLUMNS = [
    "id", "time", "updated", "latitude", "longitude", "depth_km", "mag",
    "magType", "place", "status", "tsunami", "sig", "net", "nst", "dmin",
    "rms", "gap", "magError", "depthError", "magNst", "locationSource",
    "magSource", "types", "ids", "sources", "type",
]

DERIVED_COLUMNS = [
    "year", "month", "day", "day_of_week", "hour", "depth_category",
    "is_shallow_50km", "is_deep_focus", "is_strong", "is_destructive_flag",
    "country", "continent", "alert",
]

NUMERIC_COLUMNS = [
    "latitude", "longitude", "depth_km", "mag", "tsunami", "sig", "nst",
    "dmin", "rms", "gap", "magError", "depthError", "magNst",
]
STRING_COLUMNS = [
    "id", "magType", "place", "status", "net", "locationSource",
    "magSource", "types", "ids", "sources", "type", "alert", "country",
    "continent", "day_of_week", "depth_category",
]


def _clean_text(value: Any) -> str | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = re.sub(r"\s+", " ", str(value)).strip()
    return text or None


@lru_cache(maxsize=1)
def _country_matcher() -> tuple[re.Pattern[str] | None, dict[str, str]]:
    """Build one efficient whole-word country regex from pycountry names."""
    try:
        import pycountry
    except ImportError:
        LOGGER.warning("pycountry is not installed; country parsing will be skipped")
        return None, {}

    names: dict[str, str] = {}
    for item in pycountry.countries:
        canonical = getattr(item, "name", None)
        if not canonical:
            continue
        names[canonical] = canonical
        common = getattr(item, "common_name", None)
        official = getattr(item, "official_name", None)
        if common:
            names[common] = canonical
        if official:
            names[official] = canonical

    aliases = {
        "USA": "United States",
        "U.S.A.": "United States",
        "US": "United States",
        "U.S.": "United States",
        "UK": "United Kingdom",
        "U.K.": "United Kingdom",
        "South Korea": "Korea, Republic of",
        "North Korea": "Korea, Democratic People's Republic of",
        "Russia": "Russian Federation",
        "Vietnam": "Viet Nam",
        "Iran": "Iran, Islamic Republic of",
        "Syria": "Syrian Arab Republic",
        "Bolivia": "Bolivia, Plurinational State of",
        "Tanzania": "Tanzania, United Republic of",
        "Venezuela": "Venezuela, Bolivarian Republic of",
        "Taiwan": "Taiwan, Province of China",
    }
    names.update(aliases)

    # Longer names come first so an official name is preferred over a short alias.
    labels = sorted(names, key=len, reverse=True)
    alternatives = "|".join(re.escape(label) for label in labels)
    # Require the country to be a location suffix (after a comma or "of").
    # This avoids matching incidental country words embedded in a town/region name.
    matcher = re.compile(rf"(?:,\s*|\bof\s+)(?P<country>{alternatives})\s*$", re.IGNORECASE)
    lookup = {label.casefold(): canonical for label, canonical in names.items()}
    return matcher, lookup


def extract_country(place: Any) -> str | None:
    """Extract only an explicitly named country; never geocode or infer it."""
    text = _clean_text(place)
    if not text:
        return None
    matcher, lookup = _country_matcher()
    if matcher is None:
        return None
    match = matcher.search(text)
    return lookup.get(match.group("country").casefold()) if match else None


@lru_cache(maxsize=512)
def country_to_continent(country: str | None) -> str | None:
    """Map a recognized country to a continent using an offline country library."""
    if not country:
        return None
    try:
        import country_converter as coco

        result = coco.convert(names=country, to="continent")
        valid_continents = {"africa", "asia", "europe", "north america", "south america", "oceania", "antarctica"}
        if isinstance(result, str) and result.casefold() in valid_continents:
            return result
    except (ImportError, ValueError, TypeError) as exc:
        LOGGER.debug("Continent lookup unavailable for %s: %s", country, exc)
    return None


def feature_to_record(feature: dict[str, Any]) -> dict[str, Any]:
    properties = feature.get("properties") or {}
    geometry = feature.get("geometry") or {}
    coordinates = geometry.get("coordinates") or []

    longitude = coordinates[0] if len(coordinates) > 0 else None
    latitude = coordinates[1] if len(coordinates) > 1 else None
    depth_km = coordinates[2] if len(coordinates) > 2 else None

    # GeoJSON times are epoch milliseconds. Keep UTC-aware timestamps until
    # the database boundary, where they are converted to naive UTC datetimes.
    event_time = pd.to_datetime(properties.get("time"), unit="ms", utc=True, errors="coerce")
    updated_time = pd.to_datetime(properties.get("updated"), unit="ms", utc=True, errors="coerce")

    record = {
        "id": feature.get("id") or properties.get("code"),
        "time": event_time,
        "updated": updated_time,
        "latitude": latitude,
        "longitude": longitude,
        "depth_km": depth_km,
    }
    for name in USGS_FEATURE_COLUMNS:
        if name in {"id", "time", "updated", "latitude", "longitude", "depth_km"}:
            continue
        record[name] = properties.get(name)
    # The project brief uses alert in later analysis although it is not one of
    # the 26 base fields. USGS may provide it as optional PAGER metadata.
    record["alert"] = properties.get("alert")
    return record


def clean_features(features: Iterable[dict[str, Any]]) -> pd.DataFrame:
    """Create cleaned fields and analysis-ready columns from raw GeoJSON features."""
    records = [feature_to_record(item) for item in features]
    columns = USGS_FEATURE_COLUMNS + ["alert"]
    df = pd.DataFrame.from_records(records, columns=columns)

    if df.empty:
        return pd.DataFrame(columns=USGS_FEATURE_COLUMNS + DERIVED_COLUMNS)

    df["id"] = df["id"].map(_clean_text)
    df = df.dropna(subset=["id"]).drop_duplicates(subset=["id"], keep="last").copy()

    for column in ["time", "updated"]:
        df[column] = pd.to_datetime(df[column], utc=True, errors="coerce")

    for column in NUMERIC_COLUMNS:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    for column in [
        "magType", "place", "status", "net", "locationSource", "magSource",
        "types", "ids", "sources", "type", "alert",
    ]:
        df[column] = df[column].map(_clean_text)
    df["alert"] = df["alert"].str.lower()

    # A tsunami flag is an integer indicator in the USGS catalogue.
    df["tsunami"] = df["tsunami"].where(df["tsunami"].isin([0, 1]), np.nan)

    # Retain missing measurements as NULL/NaN. Filling them with zero would
    # distort magnitude, depth, error and station-coverage statistics.
    df["year"] = df["time"].dt.year.astype("Int64")
    df["month"] = df["time"].dt.month.astype("Int64")
    df["day"] = df["time"].dt.day.astype("Int64")
    df["day_of_week"] = df["time"].dt.day_name()
    df["hour"] = df["time"].dt.hour.astype("Int64")

    df["depth_category"] = np.select(
        [df["depth_km"].le(70), df["depth_km"].gt(70) & df["depth_km"].le(300)],
        ["shallow", "intermediate"],
        default="deep",
    )
    df.loc[df["depth_km"].isna(), "depth_category"] = None
    # The 50 km threshold is explicitly used in the supplied analyst tasks.
    df["is_shallow_50km"] = df["depth_km"].lt(50).where(df["depth_km"].notna())
    df["is_deep_focus"] = df["depth_km"].gt(300).where(df["depth_km"].notna())
    df["is_strong"] = df["mag"].ge(6.0).where(df["mag"].notna())
    # Screening label only; magnitude alone does not establish actual damage.
    df["is_destructive_flag"] = df["mag"].ge(7.0).where(df["mag"].notna())

    df["country"] = df["place"].map(extract_country)
    df["continent"] = df["country"].map(country_to_continent)

    # Stable column order: all specified 26 features, optional alert, then
    # derived fields. Do not silently substitute unrelated fields.
    ordered = USGS_FEATURE_COLUMNS + [
        "alert", "year", "month", "day", "day_of_week", "hour",
        "depth_category", "is_shallow_50km", "is_deep_focus", "is_strong",
        "is_destructive_flag", "country", "continent",
    ]
    return df.reindex(columns=ordered).sort_values("time", na_position="last").reset_index(drop=True)
