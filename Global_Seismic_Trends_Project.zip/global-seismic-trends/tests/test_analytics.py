import pandas as pd

from seismic.analytics import dataset_summary, strongest_events, yearly_counts


def test_summary_and_yearly_counts():
    frame = pd.DataFrame(
        {
            "id": ["a", "b", "c"],
            "time": pd.to_datetime(["2024-01-01", "2024-02-01", "2025-01-01"], utc=True),
            "mag": [4.0, 6.1, 5.0],
            "depth_km": [10.0, 20.0, 300.0],
            "tsunami": [0, 1, 0],
            "country": ["United States", None, "Japan"],
            "continent": ["North America", None, "Asia"],
            "status": ["reviewed", "automatic", "reviewed"],
            "magType": ["mb", "mww", "mww"],
            "place": ["A", "B", "C"],
        }
    )
    summary = dataset_summary(frame)
    assert summary["total_events"] == 3
    assert summary["tsunami_flagged_events"] == 1
    assert summary["records_with_country"] == 2
    assert list(yearly_counts(frame)["event_count"]) == [2, 1]
    assert strongest_events(frame, limit=1).iloc[0]["id"] == "b"
