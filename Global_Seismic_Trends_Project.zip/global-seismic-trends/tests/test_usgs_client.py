from datetime import date
from types import SimpleNamespace

from seismic.usgs_client import USGSEarthquakeClient, _month_windows, _utc_end_inclusive


def test_month_windows_clip_to_requested_range():
    windows = list(_month_windows(date(2025, 1, 30), date(2025, 3, 2)))
    assert windows == [
        (date(2025, 1, 30), date(2025, 1, 31)),
        (date(2025, 2, 1), date(2025, 2, 28)),
        (date(2025, 3, 1), date(2025, 3, 2)),
    ]


def test_end_date_is_inclusive_to_final_millisecond():
    assert _utc_end_inclusive(date(2025, 1, 31)) == "2025-01-31T23:59:59.999Z"


def test_fetch_paginates_and_deduplicates_event_ids():
    class FakeSession:
        def __init__(self):
            self.headers = {}
            self.calls = []

        def mount(self, *_args, **_kwargs):
            pass

        def get(self, _url, params, timeout):
            self.calls.append(params["offset"])
            if params["offset"] == 1:
                features = [{"id": "one"}, {"id": "two"}]
            elif params["offset"] == 3:
                features = [{"id": "two"}, {"id": "three"}]
            else:
                features = []
            return SimpleNamespace(
                status_code=200,
                json=lambda: {"type": "FeatureCollection", "features": features},
                raise_for_status=lambda: None,
            )

    session = FakeSession()
    client = USGSEarthquakeClient(page_size=2, pause_seconds=0, session=session)
    events = client.fetch(date(2025, 1, 1), date(2025, 1, 2))

    assert session.calls == [1, 3, 5]
    assert [event["id"] for event in events] == ["one", "two", "three"]
