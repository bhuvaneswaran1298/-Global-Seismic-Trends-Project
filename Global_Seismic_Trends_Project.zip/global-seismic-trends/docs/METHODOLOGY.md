# Methodology and analytical decisions

## Workflow

1. The API client requests GeoJSON from the USGS FDSN Event Web Service.
2. The requested period is split into calendar-month windows. Each window is paginated with `limit` and `offset` so the USGS response cap is respected.
3. Failed HTTP requests are retried for transient network and server errors. Empty 204 responses are treated as no events. Records are de-duplicated by event ID.
4. GeoJSON properties and point coordinates are normalized into the 26 project fields.
5. Time columns are converted from epoch milliseconds to UTC datetimes. Numeric fields are converted to numeric types. Text whitespace is normalized with regular expressions.
6. Derived date, depth and magnitude flags are added. Missing analytical measurements remain null.
7. A cleaned CSV is written. When MySQL is configured, rows are inserted/updated using the USGS event ID as the primary key.
8. Streamlit reads MySQL or the cleaned CSV and offers filters, charts, data tables and downloads.

## Thresholds

The project brief does not specify every classification threshold. The implementation exposes the following transparent assumptions:

- Depth category: shallow <=70 km; intermediate >70 and <=300 km; deep >300 km.
- Analyst task 3's explicit shallow condition: depth <50 km and magnitude >7.5.
- Deep-focus events: depth >300 km, as specified in analyst task 30.
- Strong magnitude flag: magnitude >=6.0.
- Destructive screening flag: magnitude >=7.0. This is a filtering heuristic, not an assertion that damage occurred.
- SQL query 18 shows an example high-station threshold of `nst > 20`; modify it when your evaluator specifies another threshold.
- SQL query 24 combines normalized event frequency (70%) and average magnitude (30%). It is an explainable project ranking heuristic, not a validated seismic hazard score.

## Why country and continent are incomplete

The USGS `place` value is a text label such as a distance and direction from a named location. It does not consistently include a country. The project applies conservative Regex matching against recognized country names and common aliases only when the name appears as a trailing location suffix (after a comma or “of”); it does not infer a country from latitude/longitude. As a result, country and continent analytics may only represent a subset of events. This limitation is surfaced in the dashboard and README.

## Unsupported impact analyses in the brief

The brief asks for (11) casualties, (12) estimated economic loss per continent and (13) average economic loss by alert level. The specified 26 features and optional PAGER alert category do not provide casualty totals or monetary loss amounts. Those outputs must remain unavailable until a second impact dataset is sourced, documented, and joined to earthquake events using a transparent matching method. The application does not synthesize or guess those values.

## What the project can and cannot claim

It can summarize reported catalogue activity, magnitudes, depth, timing, review status, tsunami flags, reporting networks and data-quality fields. It cannot forecast future earthquakes, estimate damage from magnitude alone, or provide a complete country-level risk assessment without additional verified datasets.
