# Global Seismic Trends: Data-Driven Earthquake Insights

A complete educational data-analytics project built around the USGS earthquake catalogue. It retrieves GeoJSON events, cleans and validates the 26 fields specified in the project brief, stores records in MySQL, runs analytical SQL, and presents interactive insights in Streamlit.

## What is included

- **USGS ingestion:** monthly date windows, pagination, retry handling, HTTP validation and event-ID de-duplication.
- **Python preparation:** Pandas type conversion, UTC timestamps, Regex-based conservative country extraction, quality checks and derived date/depth/magnitude fields.
- **MySQL:** indexed schema for all 26 source features, optional alert metadata and derived columns; repeatable upserts avoid duplicate primary-key failures.
- **SQL analysis:** a query library covering the 30 tasks from the supplied brief, with unsupported source-data questions clearly identified.
- **Streamlit dashboard:** global epicentre map, KPIs, magnitude/depth charts, monthly and hourly patterns, status filters, largest-event table and CSV export.
- **Tests and documentation:** unit tests, data dictionary, methodology, evaluation notes and an EDA report script.

## Technology stack

Python 3.10+, Pandas, NumPy, Requests, Regex (`re`), SQLAlchemy, PyMySQL, MySQL 8.0+ or MariaDB 10.6+, Streamlit, Plotly, PyCountry, Country Converter and pytest.

## Project structure

```text
global-seismic-trends/
├── app.py
├── pyproject.toml
├── requirements.txt
├── .env.example
├── src/seismic/
│   ├── usgs_client.py       # USGS API, monthly pagination and retries
│   ├── cleaner.py           # GeoJSON parsing, cleaning and derived columns
│   ├── storage.py            # CSV and MySQL persistence
│   └── analytics.py          # reusable Pandas EDA functions
├── scripts/
│   ├── fetch_and_store.py    # ingestion CLI
│   └── run_analysis.py       # exports EDA summaries
├── sql/
│   ├── schema.sql
│   └── analysis_queries.sql  # 30 project analyst tasks
├── docs/
│   ├── DATA_DICTIONARY.md
│   └── METHODOLOGY.md
├── tests/
└── data/
    ├── raw/
    └── processed/
```

## 1. Install the project

Open a terminal in this folder.

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 2. Configure MySQL

Create a database and a user with permissions to create and update tables. Example (adjust the username/password for your machine):

```sql
CREATE DATABASE seismic_insights
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER 'seismic_user'@'localhost' IDENTIFIED BY 'change_this_password';
GRANT ALL PRIVILEGES ON seismic_insights.* TO 'seismic_user'@'localhost';
FLUSH PRIVILEGES;
```

Copy `.env.example` to `.env` and edit `DATABASE_URL`:

```text
DATABASE_URL=mysql+pymysql://seismic_user:change_this_password@localhost:3306/seismic_insights?charset=utf8mb4
```

The code creates the `earthquakes` table automatically when `--load-mysql` is enabled. The `.env` file is excluded from Git.

**CSV-only mode is supported.** You can fetch and explore the data without MySQL; simply omit `--load-mysql`.

## 3. Download and prepare five years of data

Default behavior uses a five-calendar-year lookback ending on the current UTC date and includes all reported magnitudes:

```bash
python scripts/fetch_and_store.py
```

To save the cleaned data in MySQL as well:

```bash
python scripts/fetch_and_store.py --load-mysql
```

For a smaller and faster first run, use a magnitude floor (this changes the dataset scope):

```bash
python scripts/fetch_and_store.py --min-magnitude 2.5 --load-mysql
```

Choose a specific date range:

```bash
python scripts/fetch_and_store.py --start 2021-11-01 --end 2026-11-01 --min-magnitude 2.5 --load-mysql
```

Save the original API GeoJSON as well as the cleaned CSV:

```bash
python scripts/fetch_and_store.py --save-raw --load-mysql
```

Output:

- `data/processed/earthquakes.csv` — cleaned analytical dataset.
- `data/raw/*.geojson` — optional original API response when `--save-raw` is passed.
- MySQL `earthquakes` table — when `--load-mysql` is passed.

The ingestion process splits the range into monthly requests and paginates each request using the USGS service's 20,000-event response limit. It de-duplicates by the USGS event ID. Re-running the MySQL load updates existing IDs instead of failing on duplicate keys.

## 4. Start the Streamlit dashboard

```bash
streamlit run app.py
```

The dashboard attempts MySQL first when `DATABASE_URL` is configured, then falls back to `data/processed/earthquakes.csv`. The sidebar can fetch a new five-year range directly from USGS. By default it uses a 2.5 minimum-magnitude filter for a practical first dashboard load; tick **Include all reported magnitudes** to fetch without that threshold.

The map samples at most 5,000 events for browser performance. KPIs and the other visualizations use all records matching the dashboard filters.

## 5. Run the Python EDA report

```bash
python scripts/run_analysis.py
```

This writes:

- `reports/dataset_summary.json`
- `reports/yearly_counts.csv`
- `reports/top_10_strongest.csv`

## 6. Run the SQL analyst tasks

Use MySQL 8.0+ or MariaDB 10.6+ and execute `sql/analysis_queries.sql`. For the MySQL command-line client:

```bash
mysql -u seismic_user -p seismic_insights < sql/analysis_queries.sql
```

The file contains all 30 analyst tasks from the project brief. Three impact questions are deliberately marked as unavailable because the specified USGS event fields do not include casualty counts or monetary loss. This is a data limitation, not a query that should be filled with invented values.

## 7. Run the tests

```bash
pytest -q
```

## Important analytical limitations

1. **Casualties and economic loss:** the documented 26 USGS event fields do not contain actual casualty totals or monetary-loss amounts. A separate impact dataset is required for analyst tasks 11–13.
2. **Country and continent:** USGS `place` is a human-readable location description, not a guaranteed country field. The parser uses Regex and a country-name library only when a recognized country name appears as a trailing location suffix. It does not reverse-geocode coordinates. Country/continent queries therefore cover only a subset of all events.
3. **PAGER alert:** `alert` is retained as optional metadata because the brief asks for alert analysis, but it is not one of the 26 required fields and is frequently missing.
4. **Missing numeric values:** missing measurements remain SQL `NULL` / Pandas `NaN`. Filling a missing magnitude or depth with zero would bias averages and distributions.
5. **Magnitude flags:** `is_strong` uses magnitude >= 6.0 and `is_destructive_flag` uses magnitude >= 7.0 as a screening heuristic only. Magnitude alone does not establish damage, casualties or local impact.
6. **No prediction claim:** this project analyzes observed earthquake records. It does not predict when or where the next earthquake will occur.

## Data source and attribution

Earthquake events are retrieved from the United States Geological Survey (USGS) FDSN Event Web Service:

- API endpoint: <https://earthquake.usgs.gov/fdsnws/event/1/query>
- Official API documentation: <https://earthquake.usgs.gov/fdsnws/event/1/>

The official API documentation describes GeoJSON output, UTC time parameters, magnitude filters, result limits and pagination. See the `format`, `starttime`, `endtime`, `minmagnitude`, `limit` and `offset` parameters in the official reference.

## Project evaluation mapping

| Evaluation area in the brief | Implementation |
|---|---|
| Data cleaning accuracy (35%) | `cleaner.py`, explicit type conversion, conservative Regex extraction, duplicate removal and tests |
| SQL effectiveness (35%) | `sql/analysis_queries.sql`, 30 documented analytical tasks |
| Dashboard (10%) | Interactive Streamlit filters, KPIs, map, charts and data export |
| Documentation (10%) | README, data dictionary and methodology notes |
| Organization (10%) | Modular source package, CLI scripts, environment template and automated tests |
