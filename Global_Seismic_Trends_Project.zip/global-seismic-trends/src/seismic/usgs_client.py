"""Small, defensive client for the USGS FDSN earthquake event service."""

from __future__ import annotations

import logging
import time
from datetime import date, datetime, timezone
from typing import Any, Iterator

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

LOGGER = logging.getLogger(__name__)
USGS_QUERY_URL = "https://earthquake.usgs.gov/fdsnws/event/1/query"
MAX_PAGE_SIZE = 20_000


def _month_windows(start_date: date, end_date: date) -> Iterator[tuple[date, date]]:
    """Yield inclusive month windows, clipped to the requested date range."""
    if end_date < start_date:
        raise ValueError("end_date must be on or after start_date")

    cursor = start_date.replace(day=1)
    while cursor <= end_date:
        if cursor.month == 12:
            next_month = date(cursor.year + 1, 1, 1)
        else:
            next_month = date(cursor.year, cursor.month + 1, 1)

        window_start = max(start_date, cursor)
        window_end = min(end_date, date.fromordinal(next_month.toordinal() - 1))
        yield window_start, window_end
        cursor = next_month


def _utc_start(value: date) -> str:
    return datetime(value.year, value.month, value.day, tzinfo=timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _utc_end_inclusive(value: date) -> str:
    """Return the final millisecond of a date; the USGS end boundary is inclusive."""
    return datetime(value.year, value.month, value.day, 23, 59, 59, 999000, tzinfo=timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


class USGSEarthquakeClient:
    """Fetch earthquake events in month-sized, paginated GeoJSON requests."""

    def __init__(
        self,
        base_url: str = USGS_QUERY_URL,
        timeout_seconds: int = 60,
        page_size: int = MAX_PAGE_SIZE,
        pause_seconds: float = 0.15,
        session: requests.Session | None = None,
    ) -> None:
        if not 1 <= page_size <= MAX_PAGE_SIZE:
            raise ValueError(f"page_size must be between 1 and {MAX_PAGE_SIZE}")
        self.base_url = base_url
        self.timeout_seconds = timeout_seconds
        self.page_size = page_size
        self.pause_seconds = max(0.0, pause_seconds)
        self.session = session or requests.Session()

        retry = Retry(
            total=4,
            connect=4,
            read=4,
            backoff_factor=0.8,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET"}),
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)
        self.session.headers.update(
            {
                "User-Agent": "GlobalSeismicTrends/1.0 (educational data analytics project)",
                "Accept": "application/geo+json, application/json",
            }
        )

    def _request_page(
        self,
        start: date,
        end: date,
        offset: int,
        min_magnitude: float | None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "format": "geojson",
            "starttime": _utc_start(start),
            # Exclusive next-day midnight avoids dropping events at the end of a day.
            "endtime": _utc_end_inclusive(end),
            "orderby": "time-asc",
            "limit": self.page_size,
            "offset": offset,
        }
        if min_magnitude is not None:
            params["minmagnitude"] = min_magnitude

        response = self.session.get(self.base_url, params=params, timeout=self.timeout_seconds)
        if response.status_code == 204:
            return []
        response.raise_for_status()

        payload = response.json()
        if not isinstance(payload, dict) or "features" not in payload:
            raise ValueError("USGS response did not contain a GeoJSON 'features' collection")
        features = payload.get("features") or []
        if not isinstance(features, list):
            raise ValueError("USGS GeoJSON 'features' value was not a list")
        return features

    def fetch(
        self,
        start_date: date,
        end_date: date,
        min_magnitude: float | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch all event features for a date range and de-duplicate by event id."""
        if min_magnitude is not None and not -2.0 <= float(min_magnitude) <= 10.0:
            raise ValueError("min_magnitude must be between -2 and 10, or None")

        unique: dict[str, dict[str, Any]] = {}
        for window_start, window_end in _month_windows(start_date, end_date):
            LOGGER.info("Fetching USGS events: %s to %s", window_start, window_end)
            offset = 1
            while True:
                page = self._request_page(window_start, window_end, offset, min_magnitude)
                LOGGER.info("Received %s events at offset %s", len(page), offset)
                for feature in page:
                    event_id = feature.get("id")
                    if event_id:
                        unique[str(event_id)] = feature

                if len(page) < self.page_size:
                    break
                offset += len(page)
                if self.pause_seconds:
                    time.sleep(self.pause_seconds)

        return list(unique.values())


def default_five_year_window(today: date | None = None) -> tuple[date, date]:
    """Return a five-calendar-year lookback ending today, handling leap dates."""
    today = today or datetime.now(timezone.utc).date()
    try:
        start = today.replace(year=today.year - 5)
    except ValueError:  # 29 February in a leap year
        start = today.replace(year=today.year - 5, day=28)
    return start, today
