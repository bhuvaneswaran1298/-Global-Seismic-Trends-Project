"""CSV and MySQL persistence helpers."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = PROJECT_ROOT / "sql" / "schema.sql"


def load_environment() -> None:
    load_dotenv(PROJECT_ROOT / ".env")


def get_database_url() -> str | None:
    load_environment()
    return os.getenv("DATABASE_URL")


def create_db_engine(database_url: str | None = None) -> Engine:
    url = database_url or get_database_url()
    if not url:
        raise RuntimeError("DATABASE_URL is not set. Copy .env.example to .env and configure MySQL.")
    return create_engine(url, pool_pre_ping=True, pool_recycle=1800, future=True)


def save_csv(df: pd.DataFrame, path: str | Path) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    export = df.copy()
    for col in ("time", "updated"):
        if col in export.columns:
            export[col] = pd.to_datetime(export[col], utc=True, errors="coerce").dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    export.to_csv(output, index=False, encoding="utf-8")
    return output


def _normalize_loaded_frame(df: pd.DataFrame) -> pd.DataFrame:
    for col in ("time", "updated"):
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], utc=True, errors="coerce")
    numeric_columns = (
        "latitude", "longitude", "depth_km", "mag", "tsunami", "sig", "nst",
        "dmin", "rms", "gap", "magError", "depthError", "magNst",
        "year", "month", "day", "hour",
    )
    for col in numeric_columns:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in ("is_shallow_50km", "is_deep_focus", "is_strong", "is_destructive_flag"):
        if col in df.columns:
            df[col] = df[col].map({True: True, False: False, "True": True, "False": False, 1: True, 0: False})
    return df


def load_csv(path: str | Path) -> pd.DataFrame:
    return _normalize_loaded_frame(pd.read_csv(path))


def _python_value(value: Any) -> Any:
    if value is None:
        return None
    if pd.isna(value):
        return None
    if isinstance(value, pd.Timestamp):
        if value.tzinfo is not None:
            value = value.tz_convert("UTC").tz_localize(None)
        return value.to_pydatetime()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, bool):
        return int(value)
    return value


def ensure_schema(engine: Engine) -> None:
    schema_sql = SCHEMA_PATH.read_text(encoding="utf-8")
    with engine.begin() as connection:
        connection.exec_driver_sql(schema_sql)


def upsert_mysql(df: pd.DataFrame, engine: Engine | None = None, batch_size: int = 1000) -> int:
    """Insert or update records by USGS event id (safe to run more than once)."""
    if df.empty:
        return 0
    engine = engine or create_db_engine()
    ensure_schema(engine)

    columns = list(df.columns)
    expected = {
        "id", "time", "updated", "latitude", "longitude", "depth_km", "mag",
        "magType", "place", "status", "tsunami", "sig", "net", "nst", "dmin",
        "rms", "gap", "magError", "depthError", "magNst", "locationSource",
        "magSource", "types", "ids", "sources", "type", "alert", "year",
        "month", "day", "day_of_week", "hour", "depth_category", "is_shallow_50km",
        "is_deep_focus", "is_strong", "is_destructive_flag", "country", "continent",
    }
    missing = expected.difference(columns)
    if missing:
        raise ValueError(f"Data frame is missing database columns: {sorted(missing)}")

    quoted_columns = ", ".join(f"`{name}`" for name in columns)
    bind_names = ", ".join(f":{name}" for name in columns)
    update_columns = [name for name in columns if name not in {"id"}]
    update_clause = ", ".join(f"`{name}` = VALUES(`{name}`)" for name in update_columns)
    statement = text(
        f"INSERT INTO earthquakes ({quoted_columns}) VALUES ({bind_names}) "
        f"ON DUPLICATE KEY UPDATE {update_clause}"
    )

    rows = [
        {key: _python_value(value) for key, value in row.items()}
        for row in df[columns].to_dict(orient="records")
    ]
    with engine.begin() as connection:
        for start in range(0, len(rows), batch_size):
            connection.execute(statement, rows[start : start + batch_size])
    return len(rows)


def load_mysql(engine: Engine | None = None) -> pd.DataFrame:
    engine = engine or create_db_engine()
    query = "SELECT * FROM earthquakes ORDER BY `time` DESC"
    with engine.connect() as connection:
        df = pd.read_sql_query(text(query), connection)
    return _normalize_loaded_frame(df)
