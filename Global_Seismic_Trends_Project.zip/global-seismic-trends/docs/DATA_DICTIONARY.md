# Data dictionary

The required source schema contains the following 26 USGS features. The project preserves their names and meaning. Coordinates are obtained from the GeoJSON `geometry.coordinates` array, ordered as longitude, latitude, depth in kilometres; the other source attributes come from `properties`.

| # | Field | Type in analysis | Meaning |
|---:|---|---|---|
| 1 | `id` | string | Unique USGS event identifier; primary key. |
| 2 | `time` | UTC datetime | Event origin time. |
| 3 | `updated` | UTC datetime | Latest update timestamp for the event record. |
| 4 | `latitude` | decimal | Epicentre latitude in decimal degrees. |
| 5 | `longitude` | decimal | Epicentre longitude in decimal degrees. |
| 6 | `depth_km` | decimal | Event depth in kilometres. |
| 7 | `mag` | decimal | Reported earthquake magnitude. |
| 8 | `magType` | string | Magnitude scale/type, such as `mb`, `ml` or `mww`. |
| 9 | `place` | string | USGS human-readable event location. |
| 10 | `status` | string | Review status, usually reviewed or automatic. |
| 11 | `tsunami` | integer 0/1 | USGS tsunami indicator. It is not a tsunami impact/casualty count. |
| 12 | `sig` | integer | USGS significance value. |
| 13 | `net` | string | Reporting network code. |
| 14 | `nst` | numeric | Number of seismic stations reporting the event. |
| 15 | `dmin` | numeric | Horizontal distance to the nearest station, in degrees. |
| 16 | `rms` | numeric | Root mean square of residuals. |
| 17 | `gap` | numeric | Azimuthal gap, in degrees. |
| 18 | `magError` | numeric | Magnitude uncertainty. |
| 19 | `depthError` | numeric | Depth uncertainty. |
| 20 | `magNst` | numeric | Number of stations used in magnitude calculation. |
| 21 | `locationSource` | string | Agency/network reporting the location. |
| 22 | `magSource` | string | Agency/network reporting the magnitude. |
| 23 | `types` | string | Comma-separated associated product/data types. |
| 24 | `ids` | string | Comma-separated event identifiers/aliases. |
| 25 | `sources` | string | Comma-separated reporting sources. |
| 26 | `type` | string | Event type, commonly `earthquake`. |

## Additional fields retained or derived by this implementation

| Field | Origin | Rule |
|---|---|---|
| `alert` | Optional USGS property | Retained when returned. It is not guaranteed and is not part of the 26-field source contract. |
| `year`, `month`, `day` | Derived from `time` | UTC calendar components. |
| `day_of_week` | Derived from `time` | English weekday name in UTC. |
| `hour` | Derived from `time` | UTC hour 0–23. |
| `depth_category` | Derived from `depth_km` | shallow <=70 km; intermediate >70 and <=300 km; deep >300 km. |
| `is_shallow_50km` | Derived from `depth_km` | True only when depth <50 km; matches the specific shallow threshold in analyst task 3. |
| `is_deep_focus` | Derived from `depth_km` | True only when depth >300 km. |
| `is_strong` | Derived from `mag` | True when magnitude >=6.0; a project screening threshold. |
| `is_destructive_flag` | Derived from `mag` | True when magnitude >=7.0; not proof of actual destruction. |
| `country` | Regex + PyCountry | Populated only when a recognized country name/alias appears as a trailing location suffix in `place` (after a comma or “of”). No geocoding is performed. |
| `continent` | Country Converter | Offline continent lookup from the parsed country. Remains null when country is unknown. |

## Missing values and quality

Numeric columns are converted with `pandas.to_numeric(errors="coerce")`. Missing or malformed values remain null; they are not set to zero. A missing depth is not a zero-kilometre earthquake, and a missing station count is not zero stations. Primary IDs are de-duplicated, retaining the last copy encountered in the fetched response.

`gap` and `rms` are catalogue quality indicators, not direct estimates of magnitude error or local damage. The quality ranking in query 28 is a relative screening proxy and should be described as such.
