#!/usr/bin/env python3
"""Produce a compact EDA report from the cleaned CSV or configured MySQL database."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from seismic.analytics import dataset_summary, strongest_events, yearly_counts  # noqa: E402
from seismic.storage import create_db_engine, get_database_url, load_csv, load_mysql  # noqa: E402


def main() -> int:
    csv_path = ROOT / "data" / "processed" / "earthquakes.csv"
    if get_database_url():
        try:
            frame = load_mysql(create_db_engine())
        except Exception:
            frame = load_csv(csv_path) if csv_path.exists() else None
    else:
        frame = load_csv(csv_path) if csv_path.exists() else None

    if frame is None:
        raise SystemExit("No dataset found. Run scripts/fetch_and_store.py first.")

    report_dir = ROOT / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    summary_path = report_dir / "dataset_summary.json"
    yearly_path = report_dir / "yearly_counts.csv"
    strongest_path = report_dir / "top_10_strongest.csv"

    summary_path.write_text(json.dumps(dataset_summary(frame), indent=2, default=str), encoding="utf-8")
    yearly_counts(frame).to_csv(yearly_path, index=False)
    strongest_events(frame).to_csv(strongest_path, index=False)

    print(f"EDA summary: {summary_path}")
    print(f"Yearly counts: {yearly_path}")
    print(f"Strongest events: {strongest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
